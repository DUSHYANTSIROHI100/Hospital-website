<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
  <!---bootstrap cdn link--->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
   <!-- aos css file cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
  <title>PHP & JSON File</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
   body  {
  background-image: url("https://gomohealth.com/wp-content/uploads/2018/10/doctor-holding-heart-withother-doctors-gradient-background.jpg");
}
 h1 {text-align: center;
    background-color: #20bf6b;
    font-size: 40px;}
</style>
</head>
<body>
  <section class="contact" id="contact">

    <div class="container min-vh-100">

        <div class="row justify-content-center">
       <h1 class="heading"><span> 👩‍⚕️</span> CONTACT US <span> 👩‍⚕️</span></h1>

            

    <div class="col-md-10" data-aos="flip-down">
      <form id="submit_form" method="post" action="save-form.php">  
        <table width="100%" cellpadding="10px">
          <tr>
            <td width="150px"><label>Name</label></td>
            <td><input type="text" name="fullname" autocomplete="off" /></td>
          </tr>
          <tr>
            <td><label>Age</label></td>
            <td><input type="number" name="age" autocomplete="off" /></td>
          </tr>
          <tr>
            <td><label>City</label></td>
            <td>
              <input type="text" name="city" autocomplete="off" />   
            </td>
          </tr>
          </tr>
          <tr>
            <td></td>
            <td><input type="submit" name="submit" id="submit" /></td>
          </tr>
        </table>
      </form>  
 </div>
    </div>

    </div>

</section>

<!-- aos js file cdn link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

<script>
AOS.init({
    duration:1000,
    delay:400
});
</script>
</body>
</html>
